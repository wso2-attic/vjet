vjo.type("test.Babak").protos({
 
});