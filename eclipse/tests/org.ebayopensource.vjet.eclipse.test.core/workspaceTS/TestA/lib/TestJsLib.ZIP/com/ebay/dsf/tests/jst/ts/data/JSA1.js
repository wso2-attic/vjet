vjo.ctype("com.ebay.dsf.tests.jst.ts.data.JSA1")
.protos({

    
    a:10,
    
    p:50,
    
    city:null,
    
    state:null,
    
    setCity:function(c){
        this.city=c;
    },
    
    getCity:function(){
        return this.city;
    },
    
    setState:function(s){
        this.state=s;
    },
    
    getState:function(){
        return this.state;
    }
})
.endType();